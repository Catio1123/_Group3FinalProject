package com.infotran.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infotran.springboot.dao.PlaceDaoImpl;
import com.infotran.springboot.model.Place;

@Service
@Transactional
public class PlaceServiceImpl {
	
	public PlaceServiceImpl() {
		System.out.println("---PlaceServiceImpl---------------------------------");
	}

	@Autowired
	PlaceDaoImpl placeDao;
	
	public void save(Place place) {
		placeDao.save(place);
	}
	
	public List<Place> findAll(){
		return placeDao.findAll();
	}
	
	public Place findById(Long id){
		return placeDao.findById(id);
	}
	
	public List<Place> findByType(Integer typeId){
		return placeDao.findByType(typeId);
	}
}
