package com.infotran.springboot.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infotran.springboot.model.Place;

@Repository
public class PlaceDaoImpl {
	@Autowired
	EntityManager em;
	
	public PlaceDaoImpl() {
//		System.out.println("---PlaceDaoImpl---------------------------------");
	}
	public void save(Place place) {
		em.persist(place);
	}
	
	@SuppressWarnings("unchecked")
	public List<Place> findAll(){
		String hql = "FROM Place";
		return em.createQuery(hql).getResultList();
	}
	
	public Place findById(Long id){
		return em.find(Place.class, id);
	}
	
	@SuppressWarnings("unchecked")
	public List<Place> findByType(Integer typeId){
		String hql = "FROM Place WHERE typeId = :tid";
		return em.createQuery(hql)
		         .setParameter("tid", typeId)
		         .getResultList();
	}
	
}
