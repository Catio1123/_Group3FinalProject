package com.infotran.springboot.model;

import java.sql.Blob;
import java.sql.Clob;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Place_Spring")
public class Place {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    Long    placeId;
	Integer typeId;
	String  name;
	String  phone;
	String  address;
	Double  longitude;
	Double  latitude;
	String  link;
	Clob  	comment;
	Blob  	picture;
	
	public Place(Integer  typeId, String name, String phone, String address, Double longitude, Double latitude,
			String link) {
		super();
		this.typeId = typeId;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.longitude = longitude;
		this.latitude = latitude;
		this.link = link;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public Clob getComment() {
		return comment;
	}

	public void setComment(Clob comment) {
		this.comment = comment;
	}

	public Blob getPicture() {
		return picture;
	}

	public void setPicture(Blob picture) {
		this.picture = picture;
	}

	public Place() {
	}
	
	public Long getPlaceId() {
		return placeId;
	}
	public void setPlaceId(Long placeId) {
		this.placeId = placeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Place [placeId=");
		builder.append(placeId);
		builder.append(", name=");
		builder.append(name);
		builder.append(", phone=");
		builder.append(phone);
		builder.append(", address=");
		builder.append(address);
		builder.append(", longitude=");
		builder.append(longitude);
		builder.append(", latitude=");
		builder.append(latitude);
		builder.append(", link=");
		builder.append(link);
		builder.append("]");
		return builder.toString();
	}
	
//	+ "(placeId int NOT NULL AUTO_INCREMENT Primary Key , "
//			+ " typeId		int, " 
//			+ " name    	varchar(32), " 
//			+ " phone		varchar(50), "
//			+ " address		varchar(50), " 
//			+ " longitude	float, " 
//			+ " latitude	float, "
//			+ " link 		varchar(200) " 
//			+ " ) DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci; ";


}
