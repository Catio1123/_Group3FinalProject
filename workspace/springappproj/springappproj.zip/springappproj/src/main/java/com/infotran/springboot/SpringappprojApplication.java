package com.infotran.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringappprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringappprojApplication.class, args);
	}

}
