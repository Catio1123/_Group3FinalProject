package com.infotran.springboot.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infotran.springboot.model.Place;

@Repository
public class PlaceDaoImpl {
	@Autowired
	EntityManager em;
	
	public PlaceDaoImpl() {
//		System.out.println("---PlaceDaoImpl---------------------------------");
	}
	public void save(Place place) {
		em.persist(place);
	}
	
	
}
